// color version change
$('.template-version button').on('click', function(){
    $('.template-version').toggleClass('open');
  });