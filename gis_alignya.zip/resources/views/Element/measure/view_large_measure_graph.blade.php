<div class="modal" id="viewLargeMeasureShow" role="dialog" >
        <div class="modal-dialog" style="max-width: 50%">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" id="viewLargeMeasureHide" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>                
                <div class="modal-body">
                	<div class="dashboard-line-chart">
                        <canvas id="viewlargemeasuregraph"></canvas>
                    </div> 
                    
                </div>                
            </div>
        </div>
    </div>
   